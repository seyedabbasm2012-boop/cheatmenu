package dev.cheatmenu.mixin;

import dev.cheatmenu.Config;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public abstract class BlockMixin {
    @Inject(
        method = "shouldRenderFace(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z",
        at = @At("HEAD"), cancellable = true, require = 0)
    private static void cheatmenu$xray(BlockState state, BlockState neighbor, Direction dir,
                                       CallbackInfoReturnable<Boolean> cir) {
        if (Config.xray) {
            Config.hooks++;
            cir.setReturnValue(Config.isVisible(state));
        }
    }
}

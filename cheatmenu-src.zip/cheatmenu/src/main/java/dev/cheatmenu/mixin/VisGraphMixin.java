package dev.cheatmenu.mixin;

import dev.cheatmenu.Config;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Stops the chunk visibility graph from hiding sections that are fully inside stone. */
@Mixin(targets = "net.minecraft.client.renderer.chunk.VisGraph")
public abstract class VisGraphMixin {
    @Inject(method = "setOpaque(Lnet/minecraft/core/BlockPos;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void cheatmenu$noOcclusion(BlockPos pos, CallbackInfo ci) {
        if (Config.xray) {
            Config.visHooks++;
            ci.cancel();
        }
    }
}

package dev.cheatmenu;

import java.util.EnumSet;
import java.util.function.Predicate;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public final class Config {
    private Config() {}

    public enum Ore {
        COAL("Coal", s -> s.is(BlockTags.COAL_ORES)),
        IRON("Iron", s -> s.is(BlockTags.IRON_ORES)),
        COPPER("Copper", s -> s.is(BlockTags.COPPER_ORES)),
        GOLD("Gold", s -> s.is(BlockTags.GOLD_ORES) || s.is(Blocks.NETHER_GOLD_ORE)),
        REDSTONE("Redstone", s -> s.is(BlockTags.REDSTONE_ORES)),
        LAPIS("Lapis", s -> s.is(BlockTags.LAPIS_ORES)),
        DIAMOND("Diamond", s -> s.is(BlockTags.DIAMOND_ORES)),
        EMERALD("Emerald", s -> s.is(BlockTags.EMERALD_ORES)),
        NETHER("Debris/Quartz", s -> s.is(Blocks.ANCIENT_DEBRIS) || s.is(Blocks.NETHER_QUARTZ_ORE)),
        EXTRAS("Chest/Spawner", s -> s.is(Blocks.CHEST) || s.is(Blocks.TRAPPED_CHEST)
                || s.is(Blocks.ENDER_CHEST) || s.is(Blocks.SPAWNER));

        public final String label;
        public final Predicate<BlockState> test;
        Ore(String label, Predicate<BlockState> test) { this.label = label; this.test = test; }
    }

    public static boolean xray = false;
    public static final EnumSet<Ore> ores = EnumSet.allOf(Ore.class);

    public static boolean autoClick = false;
    public static final int[] CPS = {5, 10, 15, 20};
    public static int cpsIndex = 1;

    public static boolean autoSprint = false;

    public static boolean speed = false;
    public static final double[] SPEED = {1.5, 2.0, 3.0, 4.0};
    public static int speedIndex = 0;

    public static boolean fastFly = false;
    public static final float[] FLY = {2f, 4f, 8f, 12f};
    public static int flyIndex = 0;

    /** Used by the X-Ray mixin: should this block be drawn? */
    public static boolean isVisible(BlockState state) {
        for (Ore o : ores) {
            if (o.test.test(state)) return true;
        }
        return false;
    }
}

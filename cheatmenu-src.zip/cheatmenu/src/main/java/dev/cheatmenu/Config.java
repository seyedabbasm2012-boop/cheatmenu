package dev.cheatmenu;

import java.util.EnumSet;
import java.util.function.Predicate;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public final class Config {
    private Config() {}

    private static boolean any(BlockState s, Block... blocks) {
        for (Block b : blocks) {
            if (s.is(b)) return true;
        }
        return false;
    }

    public enum Ore {
        COAL("Coal", s -> any(s, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE)),
        IRON("Iron", s -> any(s, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE)),
        COPPER("Copper", s -> any(s, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE)),
        GOLD("Gold", s -> any(s, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE)),
        REDSTONE("Redstone", s -> any(s, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE)),
        LAPIS("Lapis", s -> any(s, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE)),
        DIAMOND("Diamond", s -> any(s, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE)),
        EMERALD("Emerald", s -> any(s, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE)),
        NETHER("Debris/Quartz", s -> any(s, Blocks.ANCIENT_DEBRIS, Blocks.NETHER_QUARTZ_ORE)),
        EXTRAS("Chest/Spawner", s -> any(s, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.SPAWNER));

        public final String label;
        public final Predicate<BlockState> test;
        Ore(String label, Predicate<BlockState> test) { this.label = label; this.test = test; }
    }

    public static boolean xray = false;
    public static final EnumSet<Ore> ores = EnumSet.allOf(Ore.class);

    public static boolean autoClick = false;
    public static final int[] CPS = {5, 10, 15, 20};
    public static int cpsIndex = 1;

    public static boolean autoSprint = false;

    public static boolean speed = false;
    public static final double[] SPEED = {1.5, 2.0, 3.0, 4.0};
    public static int speedIndex = 0;

    public static boolean fastFly = false;
    public static final float[] FLY = {2f, 4f, 8f, 12f};
    public static int flyIndex = 0;

    /** Used by the X-Ray mixin: should this block be drawn? */
    public static boolean isVisible(BlockState state) {
        for (Ore o : ores) {
            if (o.test.test(state)) return true;
        }
        return false;
    }
}

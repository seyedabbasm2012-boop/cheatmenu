package dev.cheatmenu;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayDeque;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Buys string + sticks from the server shop menu, crafts bows, sells them with the shop's
 * "sell menu" (never /sellall). Every step is slow-and-checked; any problem stops the bot
 * and writes the reason to the status button and config/cheatmenu-bot.log.
 */
public final class BowBot {
    private BowBot() {}

    private enum P {
        START, BUY_OPEN, BUY_CAT, BUY_FIND, BUY_CLICK, BUY_VERIFY,
        CRAFT_OPEN, CRAFT_WAIT, CRAFT_OPS, CRAFT_VERIFY,
        SELL_OPEN, SELL_PICK, SELL_WAIT, SELL_MOVE, SELL_CLOSE
    }

    public static volatile boolean running = false;
    public static volatile String status = "idle";

    private static P phase = P.START;
    private static int wait = 0, timeout = 0, tries = 0, before = 0, cycles = 0, itemSlot = -1;
    private static int stage = 0; // 0 = string, 1 = sticks
    private static int pageTries = 0, closedTicks = 0, sellRounds = 0;
    private static final ArrayDeque<int[]> ops = new ArrayDeque<>(); // {slot, button, type}
    private static final String[] TYPES = {"PICKUP", "QUICK_MOVE", "QUICK_CRAFT"};

    // ---- config (config/cheatmenu-bot.properties) ----
    private static String shopCmd = "shop", craftCmd = "";
    private static String catString = "دراپ", catStick = "معدن", sellName = "منوی فروش";
    private static int delay = 3, verify = 6, opsPerTick = 3, nextSlot = 53, maxCycles = 0, perStack = 64;

    private static Path dir() { return FabricLoader.getInstance().getConfigDir(); }

    private static void loadConfig() {
        Path f = dir().resolve("cheatmenu-bot.properties");
        try {
            if (!Files.exists(f)) {
                String def = "# Cheat Menu - Bow Bot settings (edit and press G twice to reload)\n"
                    + "shop_command=shop\n"
                    + "# leave empty to open the crafting table you are aiming at\n"
                    + "craft_command=\n"
                    + "string_category=دراپ\n"
                    + "stick_category=معدن\n"
                    + "sell_menu_name=منوی فروش\n"
                    + "# ticks to wait after each click (20 ticks = 1 second). Lower = faster\n"
                    + "delay=3\n"
                    + "verify_ticks=6\n"
                    + "clicks_per_tick=3\n"
                    + "next_page_slot=53\n"
                    + "# 0 = run until you stop it\n"
                    + "max_cycles=0\n";
                Files.writeString(f, def, StandardCharsets.UTF_8);
            }
            Properties pr = new Properties();
            try (var r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) { pr.load(r); }
            shopCmd = pr.getProperty("shop_command", shopCmd).trim();
            craftCmd = pr.getProperty("craft_command", craftCmd).trim();
            catString = pr.getProperty("string_category", catString).trim();
            catStick = pr.getProperty("stick_category", catStick).trim();
            sellName = pr.getProperty("sell_menu_name", sellName).trim();
            delay = Integer.parseInt(pr.getProperty("delay", "3").trim());
            verify = Integer.parseInt(pr.getProperty("verify_ticks", "6").trim());
            opsPerTick = Math.max(1, Integer.parseInt(pr.getProperty("clicks_per_tick", "3").trim()));
            nextSlot = Integer.parseInt(pr.getProperty("next_page_slot", "53").trim());
            maxCycles = Integer.parseInt(pr.getProperty("max_cycles", "0").trim());
        } catch (Throwable t) {
            log("config problem, using defaults: " + t);
        }
    }

    private static void log(String s) {
        try {
            Files.writeString(dir().resolve("cheatmenu-bot.log"), s + "\n", StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Throwable ignored) {
            // logging must never break the game
        }
    }

    public static void toggle() {
        if (running) {
            stop("stopped by you");
        } else {
            loadConfig();
            running = true;
            phase = P.START;
            wait = 0; timeout = 0; tries = 0; cycles = 0; pageTries = 0; closedTicks = 0; sellRounds = 0; ops.clear();
            status = "running";
            log("--- start ---");
        }
    }

    private static void stop(String why) {
        running = false;
        status = "STOP: " + why;
        log(status);
        ops.clear();
        try {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p != null && p.containerMenu != p.inventoryMenu) p.closeContainer();
        } catch (Throwable ignored) {
            // ignore
        }
    }

    // ---------------------------------------------------------------------------------

    public static void tick(Minecraft mc) {
        if (!running) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { stop("left the world"); return; }
        if (wait > 0) { wait--; return; }
        try {
            step(mc, p);
        } catch (Throwable t) {
            Throwable c = t;
            if (c instanceof java.lang.reflect.InvocationTargetException && c.getCause() != null) c = c.getCause();
            stop("error " + c);
        }
    }

    private static void go(P next, int w) { phase = next; wait = w; timeout = 0; status = "running: " + next; }

    private static void step(Minecraft mc, LocalPlayer p) throws Exception {
        AbstractContainerMenu menu = p.containerMenu;
        boolean needsMenu = phase == P.BUY_FIND || phase == P.BUY_CLICK || phase == P.BUY_VERIFY
            || phase == P.CRAFT_OPS || phase == P.SELL_MOVE;
        if (needsMenu && menu == p.inventoryMenu) {
            if (++closedTicks >= 4) stop("menu was closed (bot stopped)");
            return;
        }
        closedTicks = 0;
        switch (phase) {
            case START -> {
                if (count(menu, p, Items.BOW) > 0) {
                    if (sellRounds >= 3) { stop("bows are not being sold (check sell menu)"); return; }
                    go(P.SELL_OPEN, 0);
                    return;
                }
                sellRounds = 0;
                if (maxCycles > 0 && cycles >= maxCycles) { stop("done, " + cycles + " cycles"); return; }
                if (largest(menu, p, Items.STRING) < 3 * (perStack / 3)) { stage = 0; tries = 0; go(P.BUY_OPEN, 0); return; }
                if (largest(menu, p, Items.STICK) < 3 * (perStack / 3)) { stage = 1; tries = 0; go(P.BUY_OPEN, 0); return; }
                go(P.CRAFT_OPEN, 0);
            }
            case BUY_OPEN -> {
                pageTries = 0;
                sendCmd(mc, shopCmd);
                go(P.BUY_CAT, delay);
            }
            case BUY_CAT -> {
                if (menu == p.inventoryMenu) { if (++timeout > 40) stop("shop did not open (check shop_command)"); return; }
                String key = norm(stage == 0 ? catString : catStick);
                int s = findByName(menu, key, "");
                if (s < 0) { if (++timeout > 30) stop("category button not found: " + key); return; }
                click(mc, p, menu, s, 0, 0);
                go(P.BUY_FIND, delay + 1);
            }
            case BUY_FIND -> {
                Item it = stage == 0 ? Items.STRING : Items.STICK;
                int cont = menu.slots.size() - 36;
                itemSlot = -1;
                for (int i = 0; i < cont; i++) {
                    if (menu.slots.get(i).getItem().is(it)) { itemSlot = i; break; }
                }
                if (itemSlot >= 0) { go(P.BUY_CLICK, 0); return; }
                if (nextSlot < cont) {
                    ItemStack nx = menu.slots.get(nextSlot).getItem();
                    if ((nx.is(Items.ARROW) || nx.is(Items.SPECTRAL_ARROW)) && pageTries++ < 8) {
                        click(mc, p, menu, nextSlot, 0, 0);
                        wait = delay + 1;
                        return;
                    }
                }
                if (++timeout > 30) stop("item not found in shop category");
            }
            case BUY_CLICK -> {
                Item it = stage == 0 ? Items.STRING : Items.STICK;
                before = count(menu, p, it);
                click(mc, p, menu, itemSlot, 0, 1); // shift + left click = buy a stack
                go(P.BUY_VERIFY, verify);
            }
            case BUY_VERIFY -> {
                Item it = stage == 0 ? Items.STRING : Items.STICK;
                if (count(menu, p, it) >= before + 16) {
                    p.closeContainer();
                    tries = 0;
                    go(P.START, delay);
                } else if (++tries > 3) {
                    stop("buying did not add items (not enough money / wrong slot?)");
                } else {
                    go(P.BUY_CLICK, delay);
                }
            }
            case CRAFT_OPEN -> {
                if (menu != p.inventoryMenu) p.closeContainer();
                if (!craftCmd.isEmpty()) sendCmd(mc, craftCmd); else startUse(mc);
                go(P.CRAFT_WAIT, delay + 2);
            }
            case CRAFT_WAIT -> {
                if (menu == p.inventoryMenu || menu.slots.size() != 46) {
                    if (++timeout > 40) stop("crafting table did not open (aim at it, or set craft_command)");
                    return;
                }
                buildCraftOps(menu, p);
                if (ops.isEmpty()) { stop("not enough sticks/string for crafting"); return; }
                go(P.CRAFT_OPS, 0);
            }
            case CRAFT_OPS -> {
                runOps(mc, p, menu);
                if (ops.isEmpty()) go(P.CRAFT_VERIFY, verify);
            }
            case CRAFT_VERIFY -> {
                if (count(menu, p, Items.BOW) > 0) {
                    p.closeContainer();
                    go(P.SELL_OPEN, delay);
                } else if (++timeout > 20) {
                    stop("craft produced nothing (grid/recipe mismatch)");
                }
            }
            case SELL_OPEN -> {
                if (menu != p.inventoryMenu) p.closeContainer();
                sendCmd(mc, shopCmd);
                go(P.SELL_PICK, delay);
            }
            case SELL_PICK -> {
                if (menu == p.inventoryMenu) { if (++timeout > 40) stop("shop did not open (sell)"); return; }
                int s = findByName(menu, norm(sellName), norm("همه"));
                if (s < 0) { if (++timeout > 30) stop("sell menu button not found: " + sellName); return; }
                click(mc, p, menu, s, 0, 0);
                go(P.SELL_WAIT, delay + 1);
            }
            case SELL_WAIT -> {
                boolean sellMenu = menu != p.inventoryMenu && menu.slots.size() == 63
                    && menuTitle(mc).contains(norm("برای فروش"));
                if (!sellMenu) { if (++timeout > 30) stop("sell window did not open"); return; }
                int cont = menu.slots.size() - 36;
                int moved = 0;
                for (int i = cont; i < menu.slots.size() && moved < cont; i++) {
                    if (menu.slots.get(i).getItem().is(Items.BOW)) { ops.add(new int[] {i, 0, 1}); moved++; }
                }
                go(P.SELL_MOVE, 0);
            }
            case SELL_MOVE -> {
                runOps(mc, p, menu);
                if (ops.isEmpty()) go(P.SELL_CLOSE, delay);
            }
            case SELL_CLOSE -> {
                p.closeContainer();
                cycles++;
                sellRounds++;
                status = "running: cycles " + cycles;
                go(P.START, delay + 2);
            }
        }
    }

    // ---- crafting ----

    private static void buildCraftOps(AbstractContainerMenu menu, LocalPlayer p) {
        ops.clear();
        for (int g = 1; g <= 9; g++) {
            if (!menu.slots.get(g).getItem().isEmpty()) ops.add(new int[] {g, 0, 1});
        }
        int stick = largest(menu, p, Items.STICK, true);
        int str = largest(menu, p, Items.STRING, true);
        if (stick < 0 || str < 0) { ops.clear(); return; }
        if (menu.slots.get(stick).getItem().getCount() < 3 || menu.slots.get(str).getItem().getCount() < 3) { ops.clear(); return; }
        drag(stick, 2, 4, 8);   // bow pattern: sticks
        drag(str, 3, 6, 9);     // bow pattern: string
        ops.add(new int[] {0, 0, 1}); // shift-click result: crafts everything it can
    }

    private static void drag(int src, int a, int b, int c) {
        ops.add(new int[] {src, 0, 0});          // pick up the whole stack
        ops.add(new int[] {-999, 0, 2});         // start left-drag
        ops.add(new int[] {a, 1, 2});
        ops.add(new int[] {b, 1, 2});
        ops.add(new int[] {c, 1, 2});
        ops.add(new int[] {-999, 2, 2});         // end drag (splits evenly)
        ops.add(new int[] {src, 0, 0});          // put the remainder back
    }

    private static void runOps(Minecraft mc, LocalPlayer p, AbstractContainerMenu menu) throws Exception {
        for (int i = 0; i < opsPerTick && !ops.isEmpty(); i++) {
            int[] o = ops.poll();
            click(mc, p, menu, o[0], o[1], o[2]);
        }
    }

    // ---- helpers ----

    private static String norm(String s) {
        return s.replace('ي', 'ی').replace('ك', 'ک')
            .replaceAll("[\\s\\u200c\\u200d\\u200e\\u200f]", "");
    }

    private static String menuTitle(Minecraft mc) {
        var sc = mc.gui.screen();
        return sc == null ? "" : norm(sc.getTitle().getString());
    }

    private static int findByName(AbstractContainerMenu menu, String key, String exclude) {
        int cont = menu.slots.size() - 36;
        for (int i = 0; i < cont; i++) {
            ItemStack st = menu.slots.get(i).getItem();
            if (st.isEmpty()) continue;
            String n = norm(st.getHoverName().getString());
            if (n.contains(key) && (exclude.isEmpty() || !n.contains(exclude))) return i;
        }
        return -1;
    }

    private static int invStart(AbstractContainerMenu menu, LocalPlayer p) {
        return menu == p.inventoryMenu ? 0 : menu.slots.size() - 36;
    }

    private static int count(AbstractContainerMenu menu, LocalPlayer p, Item item) {
        int n = 0;
        for (int i = invStart(menu, p); i < menu.slots.size(); i++) {
            ItemStack st = menu.slots.get(i).getItem();
            if (st.is(item)) n += st.getCount();
        }
        return n;
    }

    private static int largest(AbstractContainerMenu menu, LocalPlayer p, Item item) {
        int best = 0;
        for (int i = invStart(menu, p); i < menu.slots.size(); i++) {
            ItemStack st = menu.slots.get(i).getItem();
            if (st.is(item)) best = Math.max(best, st.getCount());
        }
        return best;
    }

    private static int largest(AbstractContainerMenu menu, LocalPlayer p, Item item, boolean slotIndex) {
        int best = -1, bestCount = 0;
        for (int i = invStart(menu, p); i < menu.slots.size(); i++) {
            ItemStack st = menu.slots.get(i).getItem();
            if (st.is(item) && st.getCount() > bestCount) { best = i; bestCount = st.getCount(); }
        }
        return best;
    }

    // ---- reflection: server commands, right-click, container clicks ----

    private static void sendCmd(Minecraft mc, String cmd) throws Exception {
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        Object conn = Minecraft.class.getMethod("getConnection").invoke(mc);
        if (conn == null) throw new IllegalStateException("no connection");
        conn.getClass().getMethod("sendCommand", String.class).invoke(conn, cmd);
    }

    private static void startUse(Minecraft mc) throws Exception {
        Method m = Minecraft.class.getDeclaredMethod("startUseItem");
        m.setAccessible(true);
        m.invoke(mc);
    }

    private static Method clickMethod;
    private static boolean clickLooked;

    private static void click(Minecraft mc, LocalPlayer p, AbstractContainerMenu menu,
                              int slot, int button, int type) throws Exception {
        Object gm = CheatMod.fieldValue(mc, "gameMode");
        if (gm == null) throw new IllegalStateException("gameMode not found");
        if (!clickLooked) {
            clickLooked = true;
            for (Method m : gm.getClass().getMethods()) {
                if (m.getParameterCount() < 4) continue;
                boolean hasInt = false, hasClickEnum = false;
                for (Class<?> t : m.getParameterTypes()) {
                    if (t == int.class) hasInt = true;
                    if (t.isEnum()) {
                        for (Object c : t.getEnumConstants()) {
                            if (((Enum<?>) c).name().equals("QUICK_MOVE")) hasClickEnum = true;
                        }
                    }
                }
                if (hasInt && hasClickEnum) { clickMethod = m; break; }
            }
            log("click method: " + clickMethod);
        }
        if (clickMethod == null) throw new IllegalStateException("container click method not found");
        Class<?>[] pts = clickMethod.getParameterTypes();
        Object[] args = new Object[pts.length];
        int[] ints = {menu.containerId, slot, button};
        int ii = 0;
        for (int i = 0; i < pts.length; i++) {
            Class<?> t = pts[i];
            if (t == int.class) {
                args[i] = ints[Math.min(ii++, 2)];
            } else if (t.isEnum()) {
                args[i] = enumConst(t, TYPES[type]);
            } else if (t.isInstance(p)) {
                args[i] = p;
            } else if (t.isInstance(menu)) {
                args[i] = menu;
            } else {
                throw new IllegalStateException("unknown click parameter " + t);
            }
        }
        clickMethod.invoke(gm, args);
    }

    private static Object enumConst(Class<?> t, String name) {
        for (Object c : t.getEnumConstants()) {
            if (((Enum<?>) c).name().equals(name)) return c;
        }
        throw new IllegalStateException("enum constant " + name + " missing in " + t);
    }
}

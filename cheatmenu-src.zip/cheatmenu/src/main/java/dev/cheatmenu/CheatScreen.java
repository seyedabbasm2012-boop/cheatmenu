package dev.cheatmenu;

import java.util.function.Supplier;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CheatScreen extends Screen {
    private static final int W = 200, H = 20, GAP = 24;
    private boolean oresPage = false;

    public CheatScreen() {
        super(Component.literal("Cheat Menu"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = 36;
        Button title = Button.builder(Component.literal(oresPage ? "X-Ray Blocks" : "Cheat Menu"), b -> {})
            .bounds(cx - W / 2, 8, W, H).build();
        title.active = false;
        addRenderableWidget(title);

        if (oresPage) {
            int i = 0;
            for (Config.Ore ore : Config.Ore.values()) {
                int x = cx - W - 4 + (i % 2) * (W + 8);
                int yy = y + (i / 2) * GAP;
                addRenderableWidget(button(x, yy, W,
                    () -> ore.label + ": " + onOff(Config.ores.contains(ore)),
                    () -> {
                        if (!Config.ores.remove(ore)) Config.ores.add(ore);
                        if (Config.xray) CheatMod.reloadChunks();
                    }));
                i++;
            }
            int by = y + ((i + 1) / 2) * GAP + 8;
            addRenderableWidget(Button.builder(Component.literal("Back"), b -> { oresPage = false; rebuildWidgets(); })
                .bounds(cx - W / 2, by, W, H).build());
            return;
        }

        int x = cx - W / 2;
        addRenderableWidget(button(x, y, W, () -> "X-Ray: " + onOff(Config.xray), () -> {
            Config.xray = !Config.xray;
            CheatMod.reloadChunks();
        })); y += GAP;
        addRenderableWidget(Button.builder(Component.literal("X-Ray Blocks..."), b -> { oresPage = true; rebuildWidgets(); })
            .bounds(x, y, W, H).build()); y += GAP + 6;

        addRenderableWidget(button(x, y, W, () -> "Speed: " + onOff(Config.speed), () -> Config.speed = !Config.speed)); y += GAP;
        addRenderableWidget(button(x, y, W, () -> "Speed x" + Config.SPEED[Config.speedIndex],
            () -> Config.speedIndex = (Config.speedIndex + 1) % Config.SPEED.length)); y += GAP + 6;

        addRenderableWidget(button(x, y, W, () -> "Fast Fly: " + onOff(Config.fastFly), () -> {
            Config.fastFly = !Config.fastFly;
            if (!Config.fastFly && minecraft != null && minecraft.player != null) {
                minecraft.player.getAbilities().setFlyingSpeed(0.05f);
            }
        })); y += GAP;
        addRenderableWidget(button(x, y, W, () -> "Fly Speed x" + (int) Config.FLY[Config.flyIndex],
            () -> Config.flyIndex = (Config.flyIndex + 1) % Config.FLY.length)); y += GAP + 6;

        addRenderableWidget(button(x, y, W, () -> "Auto Sprint: " + onOff(Config.autoSprint),
            () -> Config.autoSprint = !Config.autoSprint)); y += GAP;
        addRenderableWidget(button(x, y, W, () -> "Auto Click: " + onOff(Config.autoClick),
            () -> Config.autoClick = !Config.autoClick)); y += GAP;
        addRenderableWidget(button(x, y, W, () -> "Clicks/sec: " + Config.CPS[Config.cpsIndex],
            () -> Config.cpsIndex = (Config.cpsIndex + 1) % Config.CPS.length)); y += GAP + 6;

        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
            .bounds(x, y, W, H).build());
    }

    private static Button button(int x, int y, int w, Supplier<String> label, Runnable action) {
        return Button.builder(Component.literal(label.get()), b -> {
            action.run();
            b.setMessage(Component.literal(label.get()));
        }).bounds(x, y, w, H).build();
    }

    private static String onOff(boolean v) { return v ? "ON" : "OFF"; }
}

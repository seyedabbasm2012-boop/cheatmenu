package dev.cheatmenu;

import java.util.function.Supplier;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CheatScreen extends Screen {
    private static final int W = 190, H = 20, GAP = 24;
    private boolean oresPage = false;

    public CheatScreen() {
        super(Component.literal("Cheat Menu"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = 36;
        int lx = cx - W - 4;
        int rx = cx + 4;

        Button title = Button.builder(Component.literal(oresPage ? "X-Ray Blocks" : "Cheat Menu"), b -> {})
            .bounds(cx - W / 2, 8, W, H).build();
        title.active = false;
        addRenderableWidget(title);

        if (oresPage) {
            int i = 0;
            for (Config.Ore ore : Config.Ore.values()) {
                int x = (i % 2 == 0) ? lx : rx;
                int yy = top + (i / 2) * GAP;
                addRenderableWidget(button(x, yy, W,
                    () -> ore.label + ": " + onOff(Config.ores.contains(ore)),
                    () -> {
                        if (!Config.ores.remove(ore)) Config.ores.add(ore);
                        if (Config.xray) CheatMod.reloadChunks();
                    }));
                i++;
            }
            int by = top + ((i + 1) / 2) * GAP + 6;
            addRenderableWidget(Button.builder(Component.literal("Back"), b -> { oresPage = false; rebuildWidgets(); })
                .bounds(cx - W / 2, by, W, H).build());
            return;
        }

        // left column
        int y = top;
        addRenderableWidget(button(lx, y, W, () -> "X-Ray: " + onOff(Config.xray), () -> {
            Config.xray = !Config.xray;
            CheatMod.applyXray();
        })); y += GAP;
        addRenderableWidget(Button.builder(Component.literal("X-Ray Blocks..."), b -> { oresPage = true; rebuildWidgets(); })
            .bounds(lx, y, W, H).build()); y += GAP;
        addRenderableWidget(button(lx, y, W, () -> "Speed: " + onOff(Config.speed), () -> Config.speed = !Config.speed)); y += GAP;
        addRenderableWidget(button(lx, y, W, () -> "Speed x" + Config.SPEED[Config.speedIndex],
            () -> Config.speedIndex = (Config.speedIndex + 1) % Config.SPEED.length)); y += GAP;
        addRenderableWidget(button(lx, y, W, () -> "Fast Fly: " + onOff(Config.fastFly), () -> {
            Config.fastFly = !Config.fastFly;
            if (!Config.fastFly && minecraft != null && minecraft.player != null) {
                minecraft.player.getAbilities().setFlyingSpeed(0.05f);
            }
        })); y += GAP;

        // right column
        y = top;
        addRenderableWidget(button(rx, y, W, () -> "Fly Speed x" + (int) Config.FLY[Config.flyIndex],
            () -> Config.flyIndex = (Config.flyIndex + 1) % Config.FLY.length)); y += GAP;
        addRenderableWidget(button(rx, y, W, () -> "Auto Sprint: " + onOff(Config.autoSprint),
            () -> Config.autoSprint = !Config.autoSprint)); y += GAP;
        addRenderableWidget(button(rx, y, W, () -> "Auto Click: " + onOff(Config.autoClick),
            () -> Config.autoClick = !Config.autoClick)); y += GAP;
        addRenderableWidget(button(rx, y, W, () -> {
            int c = Config.CPS[Config.cpsIndex];
            return c == 0 ? "Click: Auto (cooldown)" : "Click: " + c + "/sec";
        }, () -> Config.cpsIndex = (Config.cpsIndex + 1) % Config.CPS.length)); y += GAP;
        addRenderableWidget(button(rx, y, W,
            () -> "H:" + Config.hooks + " V:" + Config.visHooks + " SC:" + Config.cullStatus + " RL:" + Config.reloadStatus,
            () -> { /* just refreshes the label */ })); y += GAP;

        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
            .bounds(cx - W / 2, y + 6, W, H).build());
    }

    private static Button button(int x, int y, int w, Supplier<String> label, Runnable action) {
        return Button.builder(Component.literal(label.get()), b -> {
            action.run();
            b.setMessage(Component.literal(label.get()));
        }).bounds(x, y, w, H).build();
    }

    private static String onOff(boolean v) { return v ? "ON" : "OFF"; }
}

package dev.cheatmenu;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

public class CheatMod implements ClientModInitializer {
    private static KeyMapping openKey;
    private int clickTimer = 0;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("cheatmenu", "main"));
        openKey = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.cheatmenu.open", InputConstants.KEY_X, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(Minecraft mc) {
        while (openKey.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreen(new CheatScreen());
        }

        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        var o = mc.options;

        // Auto sprint
        if (Config.autoSprint && o.keyUp.isDown() && !p.isUsingItem()) {
            p.setSprinting(true);
        }

        // Ground/air speed
        boolean moving = o.keyUp.isDown() || o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown();
        if (Config.speed && moving && mc.gui.screen() == null) {
            Vec3 v = p.getDeltaMovement();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            if (h > 0.001) {
                double target = 0.22 * Config.SPEED[Config.speedIndex];
                double s = target / h;
                p.setDeltaMovement(v.x * s, v.y, v.z * s);
            }
        }

        // Fly speed (flying itself must be granted by the server)
        if (Config.fastFly && p.getAbilities().flying) {
            p.getAbilities().setFlyingSpeed(0.05f * Config.FLY[Config.flyIndex]);
        }

        // Auto click (left mouse / attack)
        if (Config.autoClick && mc.gui.screen() == null) {
            int delay = Math.max(1, 20 / Config.CPS[Config.cpsIndex]);
            if (++clickTimer >= delay) {
                clickTimer = 0;
                KeyMapping.click(InputConstants.Type.MOUSE.getOrCreate(InputConstants.MOUSE_BUTTON_LEFT));
            }
        } else {
            clickTimer = 0;
        }
    }

    /** Rebuild chunk meshes so X-Ray applies immediately. Reflection = no compile break if renamed. */
    public static void reloadChunks() {
        Minecraft mc = Minecraft.getInstance();
        java.util.List<Object> targets = new java.util.ArrayList<>();
        for (String name : new String[] {"levelExtractor", "levelRenderer"}) {
            Object o = field(mc, name);
            if (o != null) {
                targets.add(o);
                Object inner = field(o, "levelExtractor");
                if (inner != null) targets.add(inner);
            }
        }
        for (Object t : targets) {
            try {
                t.getClass().getMethod("allChanged").invoke(t);
                return;
            } catch (Throwable ignored) {
                // try next candidate; if none works, the player can press F3+A
            }
        }
    }

    private static Object field(Object owner, String name) {
        for (Class<?> c = owner.getClass(); c != null; c = c.getSuperclass()) {
            try {
                java.lang.reflect.Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(owner);
            } catch (Throwable ignored) {
                // keep looking
            }
        }
        return null;
    }
}

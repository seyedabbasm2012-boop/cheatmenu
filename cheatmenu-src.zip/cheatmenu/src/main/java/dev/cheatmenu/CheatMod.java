package dev.cheatmenu;

import com.mojang.blaze3d.platform.InputConstants;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

public class CheatMod implements ClientModInitializer {
    private static KeyMapping openKey;
    private static KeyMapping botKey;
    private int clickTimer = 0;
    private int tickCount = 0;
    private boolean attackHeld = false;
    private boolean sprintHeld = false;
    private static Method startAttack;
    private static boolean startAttackLooked = false;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("cheatmenu", "main"));
        openKey = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.cheatmenu.open", InputConstants.KEY_X, category));
        botKey = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.cheatmenu.bot", InputConstants.KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(Minecraft mc) {
        while (openKey.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreen(new CheatScreen());
        }

        while (botKey.consumeClick()) {
            BowBot.toggle();
        }
        BowBot.tick(mc);
        MobSnipe.tick(mc);

        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            attackHeld = false;
            sprintHeld = false;
            return;
        }
        var o = mc.options;
        tickCount++;

        // keep chunk-visibility culling off while X-Ray is on
        if (Config.xray && tickCount % 40 == 0) {
            setSmartCull(false);
        }

        // Auto sprint: hold the sprint key while the forward key is held
        if (Config.autoSprint && o.keyUp.isDown() && !p.isUsingItem()) {
            o.keySprint.setDown(true);
            sprintHeld = true;
        } else if (sprintHeld) {
            o.keySprint.setDown(false);
            sprintHeld = false;
        }

        // Ground/air speed
        boolean moving = o.keyUp.isDown() || o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown();
        if (Config.speed && moving && mc.gui.screen() == null) {
            Vec3 v = p.getDeltaMovement();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            if (h > 0.001) {
                double target = 0.22 * Config.SPEED[Config.speedIndex];
                double s = target / h;
                p.setDeltaMovement(v.x * s, v.y, v.z * s);
            }
        }

        // Fly speed (flying itself must be granted by the server)
        if (Config.fastFly && p.getAbilities().flying) {
            p.getAbilities().setFlyingSpeed(0.05f * Config.FLY[Config.flyIndex]);
        }

        // Auto click: hold attack (breaks blocks) + real clicks (hits mobs)
        if (Config.autoClick && mc.gui.screen() == null) {
            o.keyAttack.setDown(true);
            attackHeld = true;
            int cps = Config.CPS[Config.cpsIndex];
            boolean fire;
            if (cps == 0) {
                fire = p.getAttackStrengthScale(0.0f) >= 1.0f;
            } else {
                fire = ++clickTimer >= Math.max(1, 20 / cps);
            }
            if (fire) {
                clickTimer = 0;
                attack(mc);
            }
        } else {
            if (attackHeld) {
                o.keyAttack.setDown(false);
                attackHeld = false;
            }
            clickTimer = 0;
        }
    }

    private static void attack(Minecraft mc) {
        if (!startAttackLooked) {
            startAttackLooked = true;
            try {
                startAttack = Minecraft.class.getDeclaredMethod("startAttack");
                startAttack.setAccessible(true);
            } catch (Throwable t) {
                startAttack = null;
            }
        }
        try {
            if (startAttack != null) {
                startAttack.invoke(mc);
                return;
            }
        } catch (Throwable ignored) {
            // fall through to the key-click fallback
        }
        KeyMapping.click(InputConstants.Type.MOUSE.getOrCreate(InputConstants.MOUSE_BUTTON_LEFT));
    }

    // ---- X-Ray helpers (reflection so a renamed field never breaks the build) ----

    public static void applyXray() {
        Config.cullStatus = setSmartCull(!Config.xray) ? "ok" : "no";
        Config.reloadStatus = reloadChunks() ? "ok" : "F3+A";
    }

    public static boolean reloadChunks() {
        Minecraft mc = Minecraft.getInstance();
        for (Object t : candidates(mc)) {
            try {
                Method m = t.getClass().getMethod("allChanged");
                m.invoke(t);
                return true;
            } catch (Throwable ignored) {
                // try next candidate
            }
        }
        return false;
    }

    public static boolean setSmartCull(boolean value) {
        Minecraft mc = Minecraft.getInstance();
        for (Object t : candidates(mc)) {
            Field f = findField(t.getClass(), "smartCull");
            if (f != null && f.getType() == boolean.class) {
                try {
                    f.setAccessible(true);
                    f.setBoolean(t, value);
                    return true;
                } catch (Throwable ignored) {
                    // try next
                }
            }
        }
        return false;
    }

    private static java.util.List<Object> candidates(Minecraft mc) {
        java.util.List<Object> list = new java.util.ArrayList<>();
        list.add(mc);
        for (String name : new String[] {"levelExtractor", "levelRenderer"}) {
            Object o = fieldValue(mc, name);
            if (o != null) {
                list.add(o);
                Object inner = fieldValue(o, "levelExtractor");
                if (inner != null) list.add(inner);
            }
        }
        return list;
    }

    private static Field findField(Class<?> start, String name) {
        for (Class<?> c = start; c != null; c = c.getSuperclass()) {
            try {
                return c.getDeclaredField(name);
            } catch (Throwable ignored) {
                // keep looking
            }
        }
        return null;
    }

    static Object fieldValue(Object owner, String name) {
        Field f = findField(owner.getClass(), name);
        if (f == null) return null;
        try {
            f.setAccessible(true);
            return f.get(owner);
        } catch (Throwable t) {
            return null;
        }
    }
}

package dev.cheatmenu;

import java.lang.reflect.Method;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * While sneaking, looks for the hostile mob under the player's own crosshair (no camera
 * movement) within Config.SNIPE_RANGE and attacks it. Never targets other players.
 * Server-side reach/damage checks still apply; this only removes the client's own distance limit.
 */
final class MobSnipe {
    private MobSnipe() {}

    private static Method attackMethod;
    private static boolean attackLooked;

    static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (!Config.mobSnipe || p == null || mc.level == null || mc.gui.screen() != null) {
            Config.snipeStatus = "-";
            return;
        }
        if (!mc.options.keyShift.isDown()) {
            Config.snipeStatus = "hold shift";
            return;
        }
        Entity target = findInCrosshair(mc, p, Config.SNIPE_RANGE[Config.snipeRangeIndex]);
        if (target == null) {
            Config.snipeStatus = "no target";
            return;
        }
        Config.snipeStatus = "hit " + target.getType().getDescription().getString();
        if (p.getAttackStrengthScale(0.0f) >= 1.0f) {
            attack(mc, p, target);
        }
    }

    /** Ray-traces along the player's own view vector; only entities actually under the crosshair count. */
    private static Entity findInCrosshair(Minecraft mc, LocalPlayer p, double range) {
        Vec3 eye = p.getEyePosition(1.0f);
        Vec3 look = p.getViewVector(1.0f);
        Vec3 end = eye.add(look.scale(range));
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(range))) {
            if (!(e instanceof Mob) || !(e instanceof Enemy) || !e.isAlive()) continue;
            AABB box = e.getBoundingBox().inflate(0.35);
            Optional<Vec3> hit = box.clip(eye, end);
            if (hit.isPresent()) {
                double d = hit.get().distanceToSqr(eye);
                if (d < bestDist) { bestDist = d; best = e; }
            }
        }
        return best;
    }

    private static void attack(Minecraft mc, LocalPlayer p, Entity target) {
        Object gm = CheatMod.fieldValue(mc, "gameMode");
        if (gm == null) return;
        if (!attackLooked) {
            attackLooked = true;
            for (Method m : gm.getClass().getMethods()) {
                Class<?>[] pts = m.getParameterTypes();
                if (pts.length == 2 && Player.class.isAssignableFrom(pts[0]) && Entity.class.isAssignableFrom(pts[1])) {
                    attackMethod = m;
                    break;
                }
            }
        }
        if (attackMethod == null) return;
        try {
            attackMethod.invoke(gm, p, target);
            p.swing(InteractionHand.MAIN_HAND);
        } catch (Throwable ignored) {
            // a renamed method here just means this tick's attack is skipped
        }
    }
}

#!/bin/bash
cd "$(dirname "$0")"
gradle build > ../build.log 2>&1
code=$?
if [ $code -ne 0 ]; then
  msg=$(grep -E 'error:|symbol:|What went wrong|Could not|Caused by' ../build.log \
    | sed -E 's#/home/runner/work/[^ ]*/src/main/java/##' \
    | awk '!seen[$0]++' | head -c 6000 | sed ':a;N;$!ba;s/\n/%0A/g')
  echo "::error title=BuildError::$msg"
fi
exit $code

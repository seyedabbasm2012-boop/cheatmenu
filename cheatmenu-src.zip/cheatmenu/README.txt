Cheat Menu - Fabric, Minecraft 26.3, client-side. Press X in game.

BUILD
1. Install JDK 25 and Gradle 9.5 or newer (or open this folder in IntelliJ IDEA, it does it for you).
2. In this folder run:   gradle build
3. Jar: build/libs/cheatmenu-1.0.0.jar

INSTALL
Put the jar + Fabric API (0.165.0+26.3 or newer) in your mods folder. Fabric Loader 0.19.5+.

If the build fails, send me the first error lines.
